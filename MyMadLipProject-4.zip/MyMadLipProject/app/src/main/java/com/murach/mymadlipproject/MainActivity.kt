package com.murach.mymadlipproject

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import android.app.Activity
import android.content.Context

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }



    override fun onCreateOptionsMenu(menu: Menu?):
            Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item?.itemId) {
            R.id.help -> {
                var intent = Intent(this, Help::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.settings -> {
                var intent = Intent(this, Settings::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.results -> {
                var intent = Intent(this, Results::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.mainactivity -> {
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }

            else -> return super.onOptionsItemSelected(item)
        }
    }


}