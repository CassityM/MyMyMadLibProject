package com.murach.mymadlipproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu

class Results : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)
    }
    override fun onCreateOptionsMenu(menu: Menu?):
            Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

   // Scary Story: "One day and decided it would be to walk through an . When they got in the
   // they saw puddles on the floor. They got really and ran into an . Then an halloween creature
   // jumped out and yelled, "!"
  //  They out of the and saw an lying on the ground. They ran all the way to an . When they got
  //  there their , , told them it was he who had scared them.

  //  "!" they said, "You really gave us a scare."

  //  Silly Story: "and went to the drive in to see Night of the Living .
//  It was about s that awoke from their graves every Hallowe'en at to terrorize the people of .
    //During the scariest part of the movie an landed on 's shoulder. He and his went flying everywhere.
// was so and began eating .
    //
    //Later, they both agreed that the landing on turned out to be the scariest part of the movie."

    // Action Story:"There once was a gingerbread man who had two for eyes and a for a nose. He always said, '
// as fast as you can, you can't catch me I'm the gingerbread man.' One day he ran past a , but they couldn't catch him.
// He kept running until he passed a , but they couldn't catch him either. Suddenly, he came across a river near .
// How would he cross? Then he saw a floating by. He jumped on it, but it was actually --who just so happened to love cookies :)"
}